extern crate vswhom;

use vswhom::VsFindResult;


fn main() {
    println!("{:#?}", VsFindResult::search());
}
