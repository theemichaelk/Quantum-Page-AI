# Security Policy

## Supported Versions

All versions including and above the current stable release version number.

## Reporting a Vulnerability

See https://hackerone.com/brave for details.
