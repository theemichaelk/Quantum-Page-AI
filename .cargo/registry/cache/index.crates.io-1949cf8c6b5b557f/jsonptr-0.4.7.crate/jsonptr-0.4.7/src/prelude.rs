//! Exposes the traits `Assign`, `Delete`, `Resolve`, `ResolveMut`
pub use crate::{Assign, Delete, Resolve, ResolveMut};
