mod decoder;
mod encoder;

pub(crate) use self::{decoder::Lz4Decoder, encoder::Lz4Encoder};
