#!/bin/sh
cargo readme > ./README.md